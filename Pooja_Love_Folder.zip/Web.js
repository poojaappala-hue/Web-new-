function kk(){
  document.getElementById("hh").src="kiss1.gif";
  document.getElementById("ff").innerHTML="Ummahh!";
}

function dd(){
  document.getElementById("hh").src="sticker_5.gif";
  document.getElementById("ff").innerHTML="Okahh!";
}
